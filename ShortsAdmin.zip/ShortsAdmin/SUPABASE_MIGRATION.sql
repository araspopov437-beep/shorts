-- =====================================================================
--  Миграция Supabase для поддержки админ-удаления видео
--  Выполните этот SQL в Supabase → SQL Editor
-- =====================================================================

-- 1. Добавляем поля в таблицу videos
ALTER TABLE videos
    ADD COLUMN IF NOT EXISTS is_deleted   BOOLEAN   NOT NULL DEFAULT false,
    ADD COLUMN IF NOT EXISTS delete_reason TEXT,
    ADD COLUMN IF NOT EXISTS deleted_at   TIMESTAMPTZ;

-- 2. Обновляем представление feed_videos — оно должно возвращать is_deleted
--    ЕСЛИ у вас уже есть view feed_videos, пересоздайте его:
--    (Предполагается стандартная структура — адаптируйте под свою схему)

-- DROP VIEW IF EXISTS feed_videos;
-- CREATE OR REPLACE VIEW feed_videos AS
-- SELECT
--     v.id,
--     v.user_id,
--     v.video_url,
--     v.thumbnail_url,
--     v.title,
--     v.caption,
--     v.hashtags,
--     v.music,
--     v.is_deleted,
--     v.delete_reason,
--     v.deleted_at,
--     v.created_at,
--     COALESCE(lc.cnt, 0)::int  AS likes_count,
--     COALESCE(cc.cnt, 0)::int  AS comments_count,
--     p.username,
--     p.display_name,
--     p.avatar_url
-- FROM videos v
-- LEFT JOIN profiles p ON p.id = v.user_id
-- LEFT JOIN (SELECT video_id, COUNT(*) AS cnt FROM likes    GROUP BY video_id) lc ON lc.video_id = v.id
-- LEFT JOIN (SELECT video_id, COUNT(*) AS cnt FROM comments GROUP BY video_id) cc ON cc.video_id = v.id;

-- 3. Таблица reports (если ещё не создана)
CREATE TABLE IF NOT EXISTS reports (
    id          UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
    video_id    UUID        NOT NULL REFERENCES videos(id) ON DELETE CASCADE,
    reporter_id UUID        NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    category    TEXT        NOT NULL,
    reason      TEXT        NOT NULL DEFAULT '',
    status      TEXT        NOT NULL DEFAULT 'pending'
                            CHECK (status IN ('pending', 'reviewed', 'dismissed')),
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Индекс для быстрой загрузки активных жалоб
CREATE INDEX IF NOT EXISTS reports_status_idx ON reports(status);
CREATE INDEX IF NOT EXISTS reports_video_id_idx ON reports(video_id);

-- 4. RLS для reports
ALTER TABLE reports ENABLE ROW LEVEL SECURITY;

-- Любой авторизованный пользователь может создать жалобу
CREATE POLICY IF NOT EXISTS "reports_insert" ON reports
    FOR INSERT TO authenticated
    WITH CHECK (reporter_id = auth.uid());

-- Читать жалобы может только тот, кто их создал (либо сервисная роль для админа)
-- Для админ-приложения используется anon key + RLS bypass через service_role
-- ИЛИ добавьте колонку is_admin в profiles и проверяйте её
CREATE POLICY IF NOT EXISTS "reports_select_own" ON reports
    FOR SELECT TO authenticated
    USING (reporter_id = auth.uid());

-- 5. Политика для таблицы videos: только владелец (и сервисная роль) может менять is_deleted
--    Для admиn-приложения рекомендуется использовать Supabase Service Role Key
--    ВМЕСТО anon key в Api.kt (замените SUPABASE_ANON_KEY на service_role key в admin app)

-- =====================================================================
--  ВАЖНО: Замените SUPABASE_ANON_KEY в Api.kt на ваш SERVICE ROLE KEY
--  чтобы UPDATE videos SET is_deleted=true работал без ограничений RLS.
--  Service Role Key находится: Supabase → Settings → API → service_role
--  Он НИКОГДА не должен попасть в обычное (пользовательское) приложение.
-- =====================================================================
