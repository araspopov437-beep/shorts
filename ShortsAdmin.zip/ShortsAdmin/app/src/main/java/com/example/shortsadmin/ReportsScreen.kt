package com.example.shortsadmin

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage

// ═══════════════════════════════════════════════════════ ПАНЕЛЬ ЖАЛОБ

@Composable
fun ReportsScreen(vm: AdminViewModel) {
    Box(Modifier.fillMaxSize().background(Color.Black)) {
        Column(Modifier.fillMaxSize()) {

            // ── ЗАГОЛОВОК ────────────────────────────────────────────────
            Box(
                Modifier.fillMaxWidth().background(Color(0xFF0A0A0A))
                    .statusBarsPadding().padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                Row(
                    Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(
                            "🚨 Панель жалоб",
                            color = Color.White, fontWeight = FontWeight.Black, fontSize = 20.sp
                        )
                        Text(
                            "${vm.reports.count { it.status == "pending" }} активных жалоб",
                            color = Muted, fontSize = 12.sp
                        )
                    }
                    // Кнопка обновить
                    Text(
                        "↻ Обновить",
                        color = AdminRed,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.clickable { vm.loadReports() }
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFF1A0000))
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                    )
                }
            }

            // ── СПИСОК ЖАЛОБ ─────────────────────────────────────────────
            when {
                vm.reportsLoading -> Loader()
                vm.reportsError != null -> CenterMessage(
                    "Ошибка: ${vm.reportsError}",
                    Modifier.weight(1f)
                )
                vm.reports.isEmpty() -> Box(
                    Modifier.weight(1f).fillMaxWidth(),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("✅", fontSize = 48.sp)
                        Spacer(Modifier.height(12.dp))
                        Text(
                            "Нет активных жалоб",
                            color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold
                        )
                        Text(
                            "Все жалобы обработаны",
                            color = Muted, fontSize = 14.sp,
                            modifier = Modifier.padding(top = 6.dp)
                        )
                    }
                }
                else -> LazyColumn(
                    Modifier.weight(1f).fillMaxWidth()
                ) {
                    items(vm.reports, key = { it.id }) { report ->
                        ReportCard(report, vm)
                    }
                }
            }
        }

        // ── ДЕТАЛЬНЫЙ ПРОСМОТР ЖАЛОБЫ ────────────────────────────────────
        vm.selectedReport?.let { report ->
            ReportDetailOverlay(report, vm)
        }
    }
}

// ═══════════════════════════════════════════════════════ КАРТОЧКА ЖАЛОБЫ

@Composable
fun ReportCard(report: Report, vm: AdminViewModel) {
    val video = report.video
    val reporter = report.reporter

    Box(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 6.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(CardBg)
            .clickable { vm.openReport(report) }
            .padding(12.dp)
    ) {
        Column {
            // ── строка: превью видео + инфо ──────────────────────────────
            Row(verticalAlignment = Alignment.Top) {
                // превью видео
                Box(
                    Modifier.size(64.dp).clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFF111111))
                ) {
                    if (video != null) {
                        if (video.isDeleted) {
                            Box(
                                Modifier.fillMaxSize().background(Color(0xFF1A0000)),
                                contentAlignment = Alignment.Center
                            ) {
                                Text("✕", color = AdminRed, fontSize = 24.sp)
                            }
                        } else {
                            AsyncImage(
                                model = video.thumbnailUrl ?: video.videoUrl,
                                contentDescription = null,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                        }
                    } else {
                        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Text("?", color = Muted, fontSize = 24.sp)
                        }
                    }
                }

                Spacer(Modifier.width(12.dp))

                Column(Modifier.weight(1f)) {
                    // Автор видео
                    if (video != null) {
                        Text(
                            video.authorName(),
                            color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp
                        )
                        if (!video.title.isNullOrBlank()) {
                            Text(
                                video.title, color = Color(0xFFCCCCCC), fontSize = 12.sp,
                                maxLines = 1, modifier = Modifier.padding(top = 2.dp)
                            )
                        }
                        if (video.isDeleted) {
                            Text(
                                "⛔ Видео удалено", color = AdminRed, fontSize = 11.sp,
                                modifier = Modifier.padding(top = 3.dp)
                            )
                        }
                    } else {
                        Text("Видео не найдено", color = Muted, fontSize = 13.sp)
                    }

                    Spacer(Modifier.height(6.dp))

                    // Бейджи
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        CategoryBadge(categoryLabel(report.category))
                        StatusBadge(report.status)
                    }
                }
            }

            Spacer(Modifier.height(10.dp))

            // ── строка: кто пожаловался ──────────────────────────────────
            Row(
                Modifier.fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xFF111111))
                    .padding(horizontal = 10.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Avatar(
                    url = reporter?.avatarUrl,
                    name = reporter.name(),
                    size = 28.dp
                )
                Spacer(Modifier.width(8.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        reporter.name(),
                        color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold
                    )
                    Text(
                        "@${reporter.nick()}",
                        color = Muted, fontSize = 11.sp
                    )
                }
                Text(
                    "Жалоба",
                    color = Muted, fontSize = 11.sp
                )
            }

            // Причина
            if (report.reason.isNotBlank()) {
                Spacer(Modifier.height(8.dp))
                Text(
                    "\"${report.reason}\"",
                    color = Color(0xFFCCCCCC), fontSize = 13.sp,
                    maxLines = 2
                )
            }

            Spacer(Modifier.height(8.dp))

            // ── действия ──────────────────────────────────────────────────
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Перейти к видео
                if (video != null && !video.isDeleted) {
                    Box(
                        Modifier.weight(1f).clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFF1A1A2A))
                            .clickable { vm.goToReportVideo(report) }
                            .padding(vertical = 8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            "▶ Открыть видео",
                            color = Color(0xFF64B5F6),
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                // Отклонить
                if (report.status == "pending") {
                    Box(
                        Modifier.weight(1f).clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFF111111))
                            .clickable { vm.dismissReport(report) }
                            .padding(vertical = 8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("✕ Отклонить", color = Muted, fontSize = 13.sp)
                    }
                }
            }
        }
    }
}

// ═══════════════════════════════════════════════════════ ДЕТАЛЬНЫЙ ПРОСМОТР ЖАЛОБЫ

@Composable
fun ReportDetailOverlay(report: Report, vm: AdminViewModel) {
    Box(
        Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.92f))
            .blockTouches()
    ) {
        Column(
            Modifier.fillMaxSize()
        ) {
            // Шапка
            Box(
                Modifier.fillMaxWidth().background(Color(0xFF0D0D0D))
                    .statusBarsPadding().padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                Row(
                    Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "‹",
                        color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold,
                        modifier = Modifier.clickable { vm.closeReport() }
                            .padding(end = 16.dp)
                    )
                    Text(
                        "Детали жалобы",
                        color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp
                    )
                }
            }

            LazyColumn(
                Modifier.fillMaxWidth().weight(1f).padding(horizontal = 16.dp)
            ) {

                // Профиль пользователя, который пожаловался
                item {
                    Spacer(Modifier.height(16.dp))
                    SectionTitle("👤 Кто подал жалобу")
                    Spacer(Modifier.height(8.dp))
                    Row(
                        Modifier.fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(CardBg)
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Avatar(
                            url = report.reporter?.avatarUrl,
                            name = report.reporter.name(),
                            size = 52.dp,
                            border = true
                        )
                        Spacer(Modifier.width(12.dp))
                        Column {
                            Text(
                                report.reporter.name(),
                                color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp
                            )
                            Text(
                                "@${report.reporter.nick()}",
                                color = Muted, fontSize = 13.sp
                            )
                            Text(
                                "ID: ${report.reporterId}",
                                color = Dim, fontSize = 10.sp,
                                modifier = Modifier.padding(top = 2.dp)
                            )
                        }
                    }
                }

                // Причина жалобы
                item {
                    Spacer(Modifier.height(14.dp))
                    SectionTitle("📋 Причина жалобы")
                    Spacer(Modifier.height(8.dp))
                    Column(
                        Modifier.fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(CardBg)
                            .padding(14.dp)
                    ) {
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            CategoryBadge(categoryLabel(report.category))
                            StatusBadge(report.status)
                        }
                        Spacer(Modifier.height(10.dp))
                        if (report.reason.isNotBlank()) {
                            Text(
                                report.reason,
                                color = Color.White, fontSize = 15.sp
                            )
                        } else {
                            Text("Причина не указана", color = Muted, fontSize = 14.sp)
                        }
                        Spacer(Modifier.height(6.dp))
                        Text(
                            "Подано: ${report.createdAt.take(10)}",
                            color = Dim, fontSize = 11.sp
                        )
                    }
                }

                // Видео
                item {
                    Spacer(Modifier.height(14.dp))
                    SectionTitle("🎬 Видео")
                    Spacer(Modifier.height(8.dp))
                    val video = report.video
                    if (video != null) {
                        Column(
                            Modifier.fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(CardBg)
                                .padding(14.dp)
                        ) {
                            // Превью
                            Box(
                                Modifier.fillMaxWidth().aspectRatio(16f / 9f)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(Color(0xFF111111))
                            ) {
                                if (video.isDeleted) {
                                    Box(
                                        Modifier.fillMaxSize().background(Color(0xFF1A0000)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                            Text("⛔", fontSize = 32.sp)
                                            Text(
                                                "Видео удалено",
                                                color = AdminRed, fontSize = 13.sp,
                                                modifier = Modifier.padding(top = 6.dp)
                                            )
                                        }
                                    }
                                } else {
                                    AsyncImage(
                                        model = video.thumbnailUrl ?: video.videoUrl,
                                        contentDescription = null,
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier.fillMaxSize()
                                    )
                                }
                            }

                            Spacer(Modifier.height(10.dp))

                            // Автор видео
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Avatar(
                                    url = video.avatarUrl,
                                    name = video.authorName(),
                                    size = 36.dp
                                )
                                Spacer(Modifier.width(10.dp))
                                Column {
                                    Text(
                                        video.authorName(),
                                        color = Color.White, fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp
                                    )
                                    Text(
                                        "ID: ${video.userId}",
                                        color = Dim, fontSize = 10.sp
                                    )
                                }
                            }

                            if (!video.title.isNullOrBlank()) {
                                Spacer(Modifier.height(8.dp))
                                Text(
                                    video.title, color = Color.White, fontSize = 14.sp,
                                    fontWeight = FontWeight.Medium
                                )
                            }

                            if (!video.caption.isNullOrBlank()) {
                                Text(
                                    video.caption, color = Color(0xFFCCCCCC), fontSize = 13.sp,
                                    modifier = Modifier.padding(top = 4.dp), maxLines = 3
                                )
                            }

                            Spacer(Modifier.height(6.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                Text("♥ ${formatNumber(video.likesCount)}", color = Muted, fontSize = 12.sp)
                                Text("💬 ${formatNumber(video.commentsCount)}", color = Muted, fontSize = 12.sp)
                            }
                        }
                    } else {
                        Box(
                            Modifier.fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(CardBg)
                                .padding(14.dp)
                        ) {
                            Text("Видео не найдено (возможно уже удалено)", color = Muted, fontSize = 13.sp)
                        }
                    }
                }

                // Действия
                item {
                    Spacer(Modifier.height(16.dp))
                    SectionTitle("⚡ Действия")
                    Spacer(Modifier.height(8.dp))

                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        val video = report.video

                        // Перейти к видео
                        if (video != null && !video.isDeleted) {
                            Box(
                                Modifier.fillMaxWidth()
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(Color(0xFF0D1A2A))
                                    .clickable { vm.goToReportVideo(report) }
                                    .padding(14.dp)
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Text("▶", color = Color(0xFF64B5F6), fontSize = 18.sp)
                                    Column {
                                        Text(
                                            "Открыть видео",
                                            color = Color(0xFF64B5F6),
                                            fontWeight = FontWeight.Bold, fontSize = 14.sp
                                        )
                                        Text(
                                            "Перейти в ленту к этому видео",
                                            color = Muted, fontSize = 12.sp
                                        )
                                    }
                                }
                            }
                        }

                        // Удалить видео прямо из жалобы
                        if (video != null && !video.isDeleted) {
                            Box(
                                Modifier.fillMaxWidth()
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(Color(0xFF2A0A0A))
                                    .clickable {
                                        vm.closeReport()
                                        vm.openDeletePanel(video)
                                        vm.openTab(AdminTab.FEED)
                                    }
                                    .padding(14.dp)
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Text("🛡", fontSize = 18.sp)
                                    Column {
                                        Text(
                                            "Удалить видео",
                                            color = AdminRed,
                                            fontWeight = FontWeight.Bold, fontSize = 14.sp
                                        )
                                        Text(
                                            "Удалит видео, лайки, комментарии, репосты",
                                            color = Muted, fontSize = 12.sp
                                        )
                                    }
                                }
                            }
                        }

                        // Отклонить жалобу
                        if (report.status == "pending") {
                            Box(
                                Modifier.fillMaxWidth()
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(Color(0xFF1A1A1A))
                                    .clickable { vm.dismissReport(report) }
                                    .padding(14.dp)
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Text("✕", color = Muted, fontSize = 18.sp)
                                    Column {
                                        Text(
                                            "Отклонить жалобу",
                                            color = Color.White, fontSize = 14.sp
                                        )
                                        Text(
                                            "Жалоба нарушений не выявила",
                                            color = Muted, fontSize = 12.sp
                                        )
                                    }
                                }
                            }
                        }
                    }

                    Spacer(Modifier.height(24.dp))
                }
            }
        }
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(
        text,
        color = Color(0xFF888888),
        fontSize = 13.sp,
        fontWeight = FontWeight.Bold,
        letterSpacing = 0.5.sp
    )
}
