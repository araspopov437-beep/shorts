package com.example.shortsadmin

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            AdminTheme { AdminRoot() }
        }
    }
}

// ═══════════════════════════════════════════════════════ ROOT

@Composable
private fun AdminRoot() {
    val vm: AdminViewModel = viewModel()

    LaunchedEffect(Unit) { vm.init() }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        when {
            vm.loading -> Loader()
            !vm.authed -> AdminAuthScreen(vm)
            else       -> AdminMainScreen(vm)
        }
    }
}

// ═══════════════════════════════════════════════════════ АВТОРИЗАЦИЯ

@Composable
private fun AdminAuthScreen(vm: AdminViewModel) {
    var email    by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }

    Box(
        Modifier.fillMaxSize()
            .background(
                Brush.radialGradient(
                    listOf(Color(0xFF1A0000), Color.Black),
                    radius = 1200f
                )
            )
            .statusBarsPadding(),
        contentAlignment = Alignment.Center
    ) {
        Column(
            Modifier.fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(28.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Лого и заголовок
            Box(
                Modifier.padding(bottom = 8.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(AdminRed)
                    .padding(horizontal = 18.dp, vertical = 10.dp)
            ) {
                Text("🛡", fontSize = 36.sp)
            }

            Text(
                "Shorts Admin",
                color = Color.White, fontSize = 32.sp, fontWeight = FontWeight.Black,
                modifier = Modifier.padding(top = 12.dp)
            )
            Text(
                "Панель администратора",
                color = AdminRed, fontSize = 14.sp,
                modifier = Modifier.padding(top = 4.dp, bottom = 32.dp)
            )

            // Предупреждение доступа
            Box(
                Modifier.fillMaxWidth().padding(bottom = 20.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color(0xFF1A0A00))
                    .padding(12.dp)
            ) {
                Text(
                    "⚠️ Только для авторизованных администраторов",
                    color = Color(0xFFFFB300), fontSize = 12.sp, textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
            }

            // Поля ввода
            AppField(
                email, { email = it }, "Admin Email",
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Email,
                    imeAction = ImeAction.Next
                )
            )
            Spacer(Modifier.height(12.dp))
            AppField(
                password, { password = it }, "Пароль",
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Password,
                    imeAction = ImeAction.Done
                ),
                visualTransformation = PasswordVisualTransformation()
            )

            // Ошибка
            if (vm.authError.isNotEmpty()) {
                Text(
                    vm.authError,
                    color = AdminRed, fontSize = 13.sp, textAlign = TextAlign.Center,
                    modifier = Modifier.padding(top = 12.dp)
                )
            }

            Spacer(Modifier.height(20.dp))

            PrimaryButton(
                text = if (vm.authBusy) "Проверяем..." else "Войти в панель",
                modifier = Modifier.fillMaxWidth(),
                enabled = !vm.authBusy && email.isNotBlank() && password.isNotBlank()
            ) { vm.signIn(email, password) }

            Spacer(Modifier.height(12.dp))
            Text(
                "Доступ ограничен. Несанкционированный\nвход запрещён.",
                color = Dim, fontSize = 11.sp, textAlign = TextAlign.Center
            )
        }
    }
}

// ═══════════════════════════════════════════════════════ ГЛАВНЫЙ ЭКРАН

@Composable
private fun AdminMainScreen(vm: AdminViewModel) {
    BackHandler(enabled = vm.selectedReport != null) { vm.closeReport() }

    Column(Modifier.fillMaxSize()) {
        // Контент — занимает всё пространство
        Box(Modifier.weight(1f).fillMaxWidth()) {
            when (vm.tab) {
                AdminTab.FEED    -> {
                    AdminFeedScreen(vm, active = true)
                }
                AdminTab.REPORTS -> {
                    ReportsScreen(vm)
                }
            }

            // Полноэкранный просмотр видео (из жалобы)
            if (vm.viewerVideoId != null) {
                AdminViewerOverlay(vm)
            }

            // Панель удаления
            if (vm.deletePanelVideo != null) {
                DeletePanelSheet(vm)
            }

            // Комментарии
            if (vm.commentsVideoId != null) {
                CommentsSheet(vm)
            }
        }

        // Нижняя навигация
        AdminBottomNav(vm)
    }
}

// ═══════════════════════════════════════════════════════ ПРОСМОТРЩИК ИЗ ЖАЛОБЫ

@Composable
private fun AdminViewerOverlay(vm: AdminViewModel) {
    val initialIndex = vm.viewerInitialIndex
    val videos = vm.feed
    if (videos.isEmpty()) return

    BackHandler { vm.closeViewer() }

    Box(Modifier.fillMaxSize().background(Color.Black).blockTouches()) {
        AdminVideoPager(
            videos = videos,
            startIndex = initialIndex,
            vm = vm,
            active = true,
            modifier = Modifier.fillMaxSize()
        )
        // Кнопка назад
        Box(
            Modifier.fillMaxWidth().statusBarsPadding()
                .padding(horizontal = 8.dp, vertical = 6.dp),
            contentAlignment = Alignment.TopStart
        ) {
            Text(
                "‹",
                color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.clickable { vm.closeViewer() }
                    .padding(horizontal = 12.dp)
            )
        }
    }
}

// ═══════════════════════════════════════════════════════ НИЖНЯЯ НАВИГАЦИЯ

@Composable
private fun AdminBottomNav(vm: AdminViewModel) {
    val pendingCount = vm.reports.count { it.status == "pending" }

    Row(
        Modifier.fillMaxWidth()
            .background(Color(0xFF0A0A0A))
            .navigationBarsPadding()
            .height(64.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Лента
        AdminNavItem(
            icon = "⌂",
            label = "Лента",
            active = vm.tab == AdminTab.FEED,
            modifier = Modifier.weight(1f)
        ) { vm.openTab(AdminTab.FEED) }

        // Разделитель
        Box(
            Modifier.width(1.dp).height(32.dp)
                .background(Color(0xFF222222))
        )

        // Панель жалоб
        AdminNavItem(
            icon = "🚨",
            label = "Жалобы",
            active = vm.tab == AdminTab.REPORTS,
            badge = if (pendingCount > 0) pendingCount.toString() else null,
            modifier = Modifier.weight(1f)
        ) { vm.openTab(AdminTab.REPORTS) }

        // Разделитель
        Box(
            Modifier.width(1.dp).height(32.dp)
                .background(Color(0xFF222222))
        )

        // Выход
        Column(
            Modifier.weight(1f).fillMaxSize().clickable { vm.signOut() },
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text("⎋", color = Muted, fontSize = 20.sp)
            Text("Выйти", color = Muted, fontSize = 10.sp)
        }
    }
}

@Composable
private fun AdminNavItem(
    icon: String,
    label: String,
    active: Boolean,
    badge: String? = null,
    modifier: Modifier,
    onClick: () -> Unit
) {
    Column(
        modifier.fillMaxSize().clickable(onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box {
            Text(
                icon,
                color = if (active) Color.White else Muted,
                fontSize = 22.sp
            )
            // Счётчик жалоб
            if (badge != null) {
                Box(
                    Modifier.align(Alignment.TopEnd)
                        .clip(RoundedCornerShape(6.dp))
                        .background(AdminRed)
                        .padding(horizontal = 4.dp, vertical = 1.dp)
                ) {
                    Text(badge, color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
        Text(
            label,
            color = if (active) Color.White else Muted,
            fontSize = 10.sp,
            modifier = Modifier.padding(top = 2.dp)
        )
        // Индикатор активной вкладки
        if (active) {
            Box(
                Modifier.padding(top = 3.dp)
                    .width(20.dp).height(2.dp)
                    .clip(RoundedCornerShape(1.dp))
                    .background(AdminRed)
            )
        }
    }
}
