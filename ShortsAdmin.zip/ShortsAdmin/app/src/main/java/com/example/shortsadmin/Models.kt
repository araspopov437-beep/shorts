package com.example.shortsadmin

import org.json.JSONArray
import org.json.JSONObject

// ─────────────────────── профили ───────────────────────

data class MiniProfile(
    val id: String?,
    val username: String?,
    val displayName: String?,
    val avatarUrl: String?
)

data class Profile(
    val id: String,
    val username: String?,
    val displayName: String?,
    val avatarUrl: String?
)

// ─────────────────────── видео ───────────────────────

data class Video(
    val id: String,
    val userId: String,
    val videoUrl: String,
    val thumbnailUrl: String?,
    val title: String?,
    val caption: String?,
    val likesCount: Int,
    val commentsCount: Int,
    val username: String?,
    val displayName: String?,
    val avatarUrl: String?,
    // Признак удаления администратором
    val isDeleted: Boolean = false,
    val deleteReason: String? = null
)

// ─────────────────────── жалоба ───────────────────────

data class Report(
    val id: String,
    val videoId: String,
    val reporterId: String,
    val category: String,
    val reason: String,
    val status: String,          // pending / reviewed / dismissed
    val createdAt: String,
    // Заполняются при загрузке
    val video: Video? = null,
    val reporter: MiniProfile? = null
)

// ─────────────────────── комментарий ───────────────────────

data class Comment(val id: String, val text: String, val profile: MiniProfile?)

// ─────────────────────── JSON helpers ───────────────────────

fun JSONObject.str(key: String): String? =
    if (has(key) && !isNull(key)) optString(key) else null

fun JSONArray.objects(): List<JSONObject> =
    (0 until length()).mapNotNull { optJSONObject(it) }

fun JSONObject.toMini(): MiniProfile =
    MiniProfile(str("id"), str("username"), str("display_name"), str("avatar_url"))

fun JSONObject.toProfile(): Profile = Profile(
    id = optString("id"),
    username = str("username"),
    displayName = str("display_name"),
    avatarUrl = str("avatar_url")
)

fun JSONObject.toVideo(): Video = Video(
    id = optString("id"),
    userId = optString("user_id"),
    videoUrl = optString("video_url"),
    thumbnailUrl = str("thumbnail_url")?.takeIf { it.isNotBlank() },
    title = str("title"),
    caption = str("caption"),
    likesCount = optInt("likes_count", 0),
    commentsCount = optInt("comments_count", 0),
    username = str("username"),
    displayName = str("display_name"),
    avatarUrl = str("avatar_url"),
    isDeleted = optBoolean("is_deleted", false),
    deleteReason = str("delete_reason")
)

fun JSONObject.toReport(): Report = Report(
    id = optString("id"),
    videoId = optString("video_id"),
    reporterId = optString("reporter_id"),
    category = optString("category"),
    reason = optString("reason"),
    status = optString("status", "pending"),
    createdAt = optString("created_at")
)

// ─────────────────────── форматирование имён ───────────────────────

fun nick(username: String?, displayName: String?): String {
    var v = (username ?: displayName ?: "").trim()
    if (v.contains("@")) v = v.substringBefore("@")
    return v.ifEmpty { "user" }
}

fun MiniProfile?.nick() = nick(this?.username, this?.displayName)
fun MiniProfile?.name(): String {
    val v = (this?.displayName ?: this?.username ?: "").trim()
    return if (v.isBlank()) "User" else v
}

fun Video.authorName(): String {
    val v = (displayName ?: username ?: "").trim()
    return if (v.isBlank()) "User" else v
}

fun avatarFallback(name: String): String =
    "https://ui-avatars.com/api/?name=" +
            java.net.URLEncoder.encode(name.ifEmpty { "User" }, "UTF-8") +
            "&background=222&color=fff&size=200"

fun formatNumber(n: Int): String = when {
    n >= 1_000_000 -> String.format(java.util.Locale.US, "%.1f", n / 1_000_000.0)
        .replace(".0", "") + "M"
    n >= 1_000 -> String.format(java.util.Locale.US, "%.1f", n / 1_000.0)
        .replace(".0", "") + "K"
    else -> n.toString()
}

fun categoryLabel(cat: String): String = when (cat) {
    "violence" -> "Насилие"
    "hate"     -> "Оскорбления"
    "adult"    -> "Контент 18+"
    "harm"     -> "Опасное поведение"
    "illegal"  -> "Запрещённые товары"
    "misinfo"  -> "Дезинформация"
    "spam"     -> "Спам"
    "ip"       -> "Авторские права"
    else       -> "Другое"
}
