package com.example.shortsadmin

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

// Цвета для админ-панели
val AdminRed   = Color(0xFFE53935)   // акцент — красный (опасные действия)
val AdminOrange = Color(0xFFFF6D00)  // предупреждения
val AdminGreen = Color(0xFF4CAF50)   // успех

val SheetBg = Color(0xFF1C1C1E)
val FieldBg = Color(0xFF1E1E1E)
val Muted   = Color(0xFF888888)
val Dim     = Color(0xFF666666)
val CardBg  = Color(0xFF1A1A1A)

private val AdminScheme = darkColorScheme(
    primary = AdminRed,
    onPrimary = Color.White,
    background = Color.Black,
    onBackground = Color.White,
    surface = SheetBg,
    onSurface = Color.White,
    surfaceVariant = FieldBg,
    onSurfaceVariant = Color(0xFFCCCCCC),
    error = AdminRed
)

@Composable
fun AdminTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = AdminScheme, content = content)
}

@Composable
fun Loader(modifier: Modifier = Modifier) {
    Box(modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        CircularProgressIndicator(
            color = AdminRed,
            trackColor = Color(0xFF333333),
            strokeWidth = 4.dp
        )
    }
}
