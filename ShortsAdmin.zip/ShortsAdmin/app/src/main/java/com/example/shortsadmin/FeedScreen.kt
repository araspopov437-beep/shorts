package com.example.shortsadmin

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.pager.VerticalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

// ═══════════════════════════════════════════════════════ ЛЕНТА АДМИНИСТРАТОРА

@Composable
fun AdminFeedScreen(vm: AdminViewModel, active: Boolean) {
    Box(Modifier.fillMaxSize().background(Color.Black)) {
        when {
            vm.feed.isNotEmpty() -> AdminVideoPager(
                videos = vm.feed,
                startIndex = 0,
                vm = vm,
                active = active,
                modifier = Modifier.fillMaxSize(),
                onNearEnd = { vm.loadMoreFeed() }
            )
            vm.feedLoading -> Loader()
            vm.feedError != null -> CenterMessage(vm.feedError ?: "Ошибка загрузки")
            else -> CenterMessage("Видео не найдено")
        }
    }
}

// ═══════════════════════════════════════════════════════ ПЕЙДЖЕР

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun AdminVideoPager(
    videos: List<Video>,
    startIndex: Int,
    vm: AdminViewModel,
    active: Boolean,
    modifier: Modifier = Modifier,
    onNearEnd: (() -> Unit)? = null
) {
    val pagerState = rememberPagerState(
        initialPage = startIndex.coerceIn(0, (videos.size - 1).coerceAtLeast(0))
    ) { videos.size }

    LaunchedEffect(pagerState.currentPage, videos.size) {
        if (onNearEnd != null && videos.isNotEmpty() && pagerState.currentPage >= videos.size - 3)
            onNearEnd()
    }

    VerticalPager(
        state = pagerState,
        modifier = modifier,
        key = { idx -> videos.getOrNull(idx)?.id ?: idx }
    ) { page ->
        val video = videos.getOrNull(page)
        if (video != null) {
            AdminVideoPage(video, active && pagerState.currentPage == page, vm)
        }
    }
}

// ═══════════════════════════════════════════════════════ ОДНА КАРТОЧКА

@Composable
fun AdminVideoPage(video: Video, isActive: Boolean, vm: AdminViewModel) {
    val scope = rememberCoroutineScope()
    var paused by remember(video.id) { mutableStateOf(false) }
    var rendered by remember(video.id) { mutableStateOf(false) }
    val pauseAlpha = remember { Animatable(0f) }

    LaunchedEffect(isActive) { if (!isActive) rendered = false }

    Box(Modifier.fillMaxSize().background(Color.Black)) {

        // ── ВИДЕО / ЗАГЛУШКА ──────────────────────────────────────────────

        if (video.isDeleted) {
            // Удалённое видео — показываем заглушку
            DeletedVideoPlaceholder(video.deleteReason)
        } else {
            // Нормальное видео
            Box(Modifier.fillMaxSize().clickable {
                paused = !paused
                scope.launch {
                    pauseAlpha.snapTo(1f)
                    pauseAlpha.animateTo(0f, tween(700))
                }
            }) {
                if (isActive) {
                    VideoSurface(
                        url = video.videoUrl,
                        playing = !paused,
                        onFirstFrame = { rendered = true },
                        modifier = Modifier.fillMaxSize()
                    )
                }
                if (!isActive || !rendered) {
                    AsyncImage(
                        model = video.thumbnailUrl ?: video.videoUrl,
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize().background(Color(0xFF111111))
                    )
                }
            }

            if (pauseAlpha.value > 0.01f) {
                Box(
                    Modifier.align(Alignment.Center).alpha(pauseAlpha.value).size(80.dp)
                        .clip(CircleShape).background(Color.Black.copy(alpha = 0.5f)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(if (paused) "❚❚" else "▶", color = Color.White, fontSize = 30.sp)
                }
            }
        }

        // ── ЗАТЕМНЕНИЕ ────────────────────────────────────────────────────

        if (!video.isDeleted) {
            Box(
                Modifier.fillMaxSize().background(
                    Brush.verticalGradient(
                        0f to Color.Black.copy(alpha = 0.35f),
                        0.15f to Color.Transparent,
                        0.65f to Color.Transparent,
                        1f to Color.Black.copy(alpha = 0.8f)
                    )
                )
            )
        }

        // ── ИНФОРМАЦИЯ ────────────────────────────────────────────────────

        Column(
            Modifier.align(Alignment.BottomStart)
                .padding(start = 14.dp, end = 90.dp, bottom = 18.dp)
        ) {
            Text(
                video.authorName(),
                color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(bottom = 4.dp)
            )
            if (!video.title.isNullOrBlank()) {
                Text(
                    video.title, color = Color.White, fontSize = 15.sp,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(bottom = 3.dp)
                )
            }
            if (!video.caption.isNullOrBlank()) {
                Text(
                    video.caption, color = Color(0xFFCCCCCC), fontSize = 13.sp,
                    maxLines = 3, modifier = Modifier.padding(bottom = 4.dp)
                )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("♥ ${formatNumber(video.likesCount)}", color = Muted, fontSize = 13.sp)
                Text("💬 ${formatNumber(video.commentsCount)}", color = Muted, fontSize = 13.sp)
            }
        }

        // ── КНОПКИ СПРАВА ─────────────────────────────────────────────────

        Column(
            Modifier.align(Alignment.BottomEnd)
                .padding(end = 10.dp, bottom = 18.dp)
                .navigationBarsPadding(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Avatar(
                url = video.avatarUrl, name = video.authorName(), size = 44.dp, border = true
            )
            // Кнопка «Комментарии»
            AdminActionBtn("💬", "Комменты") { vm.openComments(video.id) }

            // Кнопка «Панель» — главная фишка администратора
            if (!video.isDeleted) {
                AdminActionBtn(
                    icon = "🛡",
                    label = "Панель",
                    tint = AdminRed,
                    bgTint = Color(0x33E53935)
                ) { vm.openDeletePanel(video) }
            } else {
                // Удалённое — показать статус
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(
                        Modifier.size(43.dp).clip(CircleShape)
                            .background(Color(0xFF2A0A0A)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("✕", color = AdminRed, fontSize = 20.sp)
                    }
                    Text("Удалено", color = AdminRed, fontSize = 10.sp,
                        modifier = Modifier.padding(top = 2.dp))
                }
            }
        }

        // ── ШАПКА: бейдж ADMIN ────────────────────────────────────────────

        Box(
            Modifier.fillMaxWidth().statusBarsPadding().padding(top = 8.dp, end = 12.dp),
            contentAlignment = Alignment.TopEnd
        ) {
            Text(
                "ADMIN",
                color = Color.White,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier
                    .clip(RoundedCornerShape(6.dp))
                    .background(AdminRed)
                    .padding(horizontal = 8.dp, vertical = 3.dp)
            )
        }
    }
}

@Composable
private fun AdminActionBtn(
    icon: String,
    label: String,
    tint: Color = Color.White,
    bgTint: Color = Color.Black.copy(alpha = 0.3f),
    onClick: () -> Unit
) {
    Column(
        Modifier.clickable(onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(3.dp)
    ) {
        Box(
            Modifier.size(43.dp).clip(CircleShape).background(bgTint),
            contentAlignment = Alignment.Center
        ) {
            Text(icon, color = tint, fontSize = 22.sp)
        }
        Text(label, color = tint, fontSize = 10.sp)
    }
}

// ═══════════════════════════════════════════════════════ ЗАГЛУШКА УДАЛЁННОГО ВИДЕО

@Composable
fun DeletedVideoPlaceholder(reason: String?) {
    Box(
        Modifier.fillMaxSize().background(Color(0xFF0D0D0D)),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.padding(32.dp)
        ) {
            Text("⛔", fontSize = 48.sp)
            Text(
                "Это видео было удалено\nиз-за нарушений правил сообщества",
                color = Color(0xFFCCCCCC),
                fontSize = 15.sp,
                fontWeight = FontWeight.Medium,
                textAlign = TextAlign.Center
            )
            if (!reason.isNullOrBlank()) {
                Text(
                    "Причина: $reason",
                    color = Muted,
                    fontSize = 13.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFF1A1A1A))
                        .padding(horizontal = 14.dp, vertical = 8.dp)
                )
            }
            Text(
                "[Видео администратора — статус «удалено»]",
                color = Dim,
                fontSize = 11.sp,
                textAlign = TextAlign.Center
            )
        }
    }
}

// ═══════════════════════════════════════════════════════ ВИДЕО-ПЛЕЕР (Media3)

@Composable
fun VideoSurface(
    url: String,
    playing: Boolean,
    onFirstFrame: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val playingState = rememberUpdatedState(playing)
    val firstFrameState = rememberUpdatedState(onFirstFrame)

    val exo = remember(url) {
        ExoPlayer.Builder(context).build().apply {
            repeatMode = Player.REPEAT_MODE_ONE
            setMediaItem(MediaItem.fromUri(url))
            playWhenReady = playingState.value
            prepare()
        }
    }

    DisposableEffect(exo) {
        val listener = object : Player.Listener {
            override fun onRenderedFirstFrame() { firstFrameState.value() }
        }
        exo.addListener(listener)
        onDispose { exo.removeListener(listener); exo.release() }
    }

    LaunchedEffect(playing, exo) { exo.playWhenReady = playing }

    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner, exo) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_STOP  -> exo.pause()
                Lifecycle.Event.ON_START -> exo.playWhenReady = playingState.value
                else -> {}
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    AndroidView(
        modifier = modifier,
        factory = { ctx ->
            PlayerView(ctx).apply {
                useController = false
                resizeMode = AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                setShutterBackgroundColor(android.graphics.Color.TRANSPARENT)
                this.player = exo
            }
        },
        update = { v -> if (v.player !== exo) v.player = exo }
    )
}
