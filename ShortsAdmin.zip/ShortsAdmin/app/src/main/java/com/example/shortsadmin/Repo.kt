package com.example.shortsadmin

import org.json.JSONObject

class Repo(private val api: Api) {

    // ─────────── видео ───────────

    /** Загрузить все видео (включая удалённые) для ленты администратора */
    suspend fun allVideos(limit: Int = 30, offset: Int = 0): List<Video> =
        api.select(
            "feed_videos",
            "select" to "*",
            "order" to "created_at.desc",
            "limit" to limit.toString(),
            "offset" to offset.toString()
        ).objects().map { it.toVideo() }

    /** Пометить видео как удалённое администратором.
     *  Устанавливаем is_deleted=true и delete_reason, очищаем лайки/комменты/репосты. */
    suspend fun adminDeleteVideo(videoId: String, reason: String) {
        // 1. Помечаем видео как удалённое (не физическое удаление — сохраняем запись)
        api.update(
            "videos",
            listOf("id" to "eq.$videoId"),
            JSONObject()
                .put("is_deleted", true)
                .put("delete_reason", reason)
                .put("deleted_at", java.time.Instant.now().toString())
        )
        // 2. Удаляем лайки
        api.delete("likes", "video_id" to "eq.$videoId")
        // 3. Удаляем комментарии
        api.delete("comments", "video_id" to "eq.$videoId")
        // 4. Удаляем репосты
        api.delete("reposts", "video_id" to "eq.$videoId")
        // 5. Удаляем из закладок
        try { api.delete("saved_videos", "video_id" to "eq.$videoId") } catch (_: Exception) {}
        // 6. Помечаем все жалобы на это видео как проверенные
        api.update(
            "reports",
            listOf("video_id" to "eq.$videoId"),
            JSONObject().put("status", "reviewed")
        )
    }

    // ─────────── жалобы ───────────

    /** Загрузить все активные жалобы (status = pending) */
    suspend fun pendingReports(): List<Report> {
        val rows = api.select(
            "reports",
            "select" to "*",
            "status" to "eq.pending",
            "order" to "created_at.desc",
            "limit" to "100"
        ).objects().map { it.toReport() }

        if (rows.isEmpty()) return emptyList()

        // Загружаем информацию о видео для каждой жалобы
        val videoIds = rows.mapNotNull { it.videoId }.distinct()
        val videos = if (videoIds.isNotEmpty()) {
            val ids = "in.(${videoIds.joinToString(",")})"
            api.select("feed_videos", "select" to "*", "id" to ids)
                .objects().associate { it.optString("id") to it.toVideo() }
        } else emptyMap()

        // Загружаем профили тех, кто пожаловался
        val reporterIds = rows.mapNotNull { it.reporterId }.distinct()
        val reporters = if (reporterIds.isNotEmpty()) {
            val ids = "in.(${reporterIds.joinToString(",")})"
            api.select("profiles", "select" to "id,username,display_name,avatar_url", "id" to ids)
                .objects().associate { it.optString("id") to it.toMini() }
        } else emptyMap()

        return rows.map { r ->
            r.copy(
                video = videos[r.videoId],
                reporter = reporters[r.reporterId]
            )
        }
    }

    /** Отклонить жалобу (пометить как dismissed) */
    suspend fun dismissReport(reportId: String) =
        api.update(
            "reports",
            listOf("id" to "eq.$reportId"),
            JSONObject().put("status", "dismissed")
        )

    // ─────────── комментарии для видео ───────────

    suspend fun videoComments(videoId: String): List<Comment> =
        api.select(
            "comments",
            "select" to "id,text,profiles:user_id(id,username,display_name,avatar_url)",
            "video_id" to "eq.$videoId",
            "order" to "created_at.asc",
            "limit" to "50"
        ).objects().map { o ->
            val profile = o.optJSONObject("profiles")?.toMini()
            Comment(o.optString("id"), o.optString("text"), profile)
        }

    // ─────────── профиль ───────────

    suspend fun getProfile(id: String): Profile? =
        api.select("profiles", "select" to "*", "id" to "eq.$id", "limit" to "1")
            .optJSONObject(0)?.toProfile()
}
