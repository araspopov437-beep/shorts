package com.example.shortsadmin

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.BottomSheetDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties

// ═══════════════════════════════════════════════════════ ОБЩАЯ ОБОЛОЧКА

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DarkSheet(onDismiss: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    val state = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = state,
        containerColor = SheetBg,
        contentColor = Color.White,
        dragHandle = { BottomSheetDefaults.DragHandle(color = Color(0xFF555555)) }
    ) {
        Column(
            Modifier.fillMaxWidth().navigationBarsPadding().imePadding().padding(bottom = 12.dp),
            content = content
        )
    }
}

@Composable
private fun SheetTitle(text: String, color: Color = Color.White) {
    Text(
        text, color = color, fontWeight = FontWeight.Bold, fontSize = 16.sp,
        textAlign = TextAlign.Center,
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp)
    )
}

// ═══════════════════════════════════════════════════════ ПАНЕЛЬ УДАЛЕНИЯ ВИДЕО

@Composable
fun DeletePanelSheet(vm: AdminViewModel) {
    val video = vm.deletePanelVideo ?: return
    DarkSheet(onDismiss = { vm.closeDeletePanel() }) {
        // Заголовок с предупреждением
        Box(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp).padding(top = 4.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(Color(0xFF2A0A0A))
                .padding(12.dp)
        ) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("🛡", fontSize = 18.sp)
                    Spacer(Modifier.width(8.dp))
                    Text(
                        "Панель модератора",
                        color = AdminRed, fontWeight = FontWeight.Bold, fontSize = 15.sp
                    )
                }
                Spacer(Modifier.height(6.dp))
                Text(
                    "Видео: \"${video.title?.take(50) ?: video.id}\"",
                    color = Color(0xFFCCCCCC), fontSize = 13.sp
                )
                Text(
                    "Автор: ${video.authorName()}",
                    color = Muted, fontSize = 12.sp
                )
            }
        }

        Spacer(Modifier.height(14.dp))

        // Предупреждение о последствиях
        Column(Modifier.padding(horizontal = 16.dp)) {
            Text(
                "После удаления будет выполнено:",
                color = Color(0xFFCCCCCC), fontSize = 13.sp, fontWeight = FontWeight.Bold
            )
            Spacer(Modifier.height(6.dp))
            listOf(
                "⛔ Видео заменится на сообщение о нарушении",
                "🗑 Удалены все комментарии",
                "🗑 Удалены все лайки",
                "🗑 Удалены все репосты",
                "🗑 Удалено из закладок"
            ).forEach { item ->
                Text(item, color = Muted, fontSize = 12.sp,
                    modifier = Modifier.padding(vertical = 2.dp))
            }
        }

        Spacer(Modifier.height(14.dp))

        // Поле причины
        Column(Modifier.padding(horizontal = 16.dp)) {
            Text(
                "Причина удаления",
                color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(bottom = 8.dp)
            )
            AppField(
                value = vm.deleteReason,
                onValueChange = { vm.onDeleteReasonChange(it) },
                placeholder = "Опишите причину (необязательно)...",
                singleLine = false,
                minLines = 3,
                maxLines = 5,
                maxLength = 300
            )
            Text(
                "${vm.deleteReason.length}/300",
                color = Dim, fontSize = 11.sp,
                modifier = Modifier.align(Alignment.End).padding(top = 4.dp)
            )
        }

        Spacer(Modifier.height(16.dp))

        // Кнопки
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            SecondaryButton(
                "Отмена",
                modifier = Modifier.weight(1f),
                enabled = !vm.deleteBusy
            ) { vm.closeDeletePanel() }

            PrimaryButton(
                text = if (vm.deleteBusy) "Удаляем..." else "Удалить видео",
                modifier = Modifier.weight(1f),
                enabled = !vm.deleteBusy,
                color = AdminRed
            ) { vm.confirmDelete() }
        }

        Spacer(Modifier.height(8.dp))
    }
}

// ═══════════════════════════════════════════════════════ КОММЕНТАРИИ

@Composable
fun CommentsSheet(vm: AdminViewModel) {
    DarkSheet(onDismiss = { vm.closeComments() }) {
        SheetTitle("Комментарии")
        Box(Modifier.fillMaxWidth().heightIn(min = 200.dp, max = 440.dp)) {
            when {
                vm.commentsLoading -> Loader()
                vm.comments.isNotEmpty() -> LazyColumn(
                    Modifier.fillMaxWidth().padding(horizontal = 16.dp)
                ) {
                    items(vm.comments, key = { it.id }) { c ->
                        Row(
                            Modifier.fillMaxWidth().padding(vertical = 8.dp),
                            verticalAlignment = Alignment.Top
                        ) {
                            Avatar(
                                url = c.profile?.avatarUrl,
                                name = c.profile.name(),
                                size = 36.dp
                            )
                            Column(Modifier.padding(start = 10.dp)) {
                                Text(
                                    c.profile.name(),
                                    color = Muted, fontSize = 12.sp, fontWeight = FontWeight.Bold
                                )
                                Text(c.text, color = Color.White, fontSize = 14.sp)
                            }
                        }
                    }
                }
                else -> CenterMessage("Комментариев нет")
            }
        }
    }
}
