package com.example.shortsadmin

import android.app.Application
import android.widget.Toast
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch

enum class AdminTab { FEED, REPORTS }

class AdminViewModel(app: Application) : AndroidViewModel(app) {

    private val api = Api(app)
    private val repo = Repo(api)

    // ═══════════════════════════════ СОСТОЯНИЕ СЕССИИ

    var loading by mutableStateOf(true);       private set
    var authed by mutableStateOf(false);       private set
    var isAdmin by mutableStateOf(false);      private set
    var meId by mutableStateOf<String?>(null); private set

    var authBusy by mutableStateOf(false);     private set
    var authError by mutableStateOf("");       private set

    // ═══════════════════════════════ НАВИГАЦИЯ

    var tab by mutableStateOf(AdminTab.FEED);  private set

    fun openTab(t: AdminTab) {
        tab = t
        if (t == AdminTab.REPORTS && reports.isEmpty() && !reportsLoading) loadReports()
    }

    // ═══════════════════════════════ ЛЕНТА

    var feed by mutableStateOf<List<Video>>(emptyList()); private set
    var feedLoading by mutableStateOf(false);              private set
    var feedError by mutableStateOf<String?>(null);        private set
    private var feedOffset = 0
    private val PAGE = 20

    fun loadFeed(refresh: Boolean = true) {
        if (feedLoading) return
        viewModelScope.launch {
            feedLoading = true
            feedError = null
            try {
                if (refresh) { feedOffset = 0; feed = emptyList() }
                val page = repo.allVideos(PAGE, feedOffset)
                feed = if (refresh) page else feed + page
                feedOffset += page.size
            } catch (e: CancellationException) { throw e
            } catch (e: Exception) { feedError = e.message }
            feedLoading = false
        }
    }

    fun loadMoreFeed() {
        if (!feedLoading && feedOffset > 0) loadFeed(refresh = false)
    }

    // ═══════════════════════════════ КОММЕНТАРИИ

    var commentsVideoId by mutableStateOf<String?>(null); private set
    var comments by mutableStateOf<List<Comment>>(emptyList()); private set
    var commentsLoading by mutableStateOf(false); private set

    fun openComments(videoId: String) {
        commentsVideoId = videoId
        viewModelScope.launch {
            commentsLoading = true
            try { comments = repo.videoComments(videoId) }
            catch (_: Exception) { comments = emptyList() }
            commentsLoading = false
        }
    }

    fun closeComments() { commentsVideoId = null; comments = emptyList() }

    // ═══════════════════════════════ ПАНЕЛЬ УДАЛЕНИЯ

    var deletePanelVideo by mutableStateOf<Video?>(null); private set
    var deleteReason by mutableStateOf("");              private set
    var deleteBusy by mutableStateOf(false);             private set

    fun openDeletePanel(video: Video) { deletePanelVideo = video; deleteReason = "" }
    fun closeDeletePanel() { deletePanelVideo = null; deleteReason = "" }
    fun onDeleteReasonChange(v: String) { deleteReason = v }

    fun confirmDelete() {
        val v = deletePanelVideo ?: return
        val reason = deleteReason.trim()
        viewModelScope.launch {
            deleteBusy = true
            try {
                repo.adminDeleteVideo(v.id, reason)
                // Обновляем видео в ленте: помечаем как удалённое
                val deleted = v.copy(isDeleted = true, deleteReason = reason)
                feed = feed.map { if (it.id == v.id) deleted else it }
                // Убираем из просматриваемого видео, если это оно
                if (viewerVideoId == v.id) closeViewer()
                // Обновляем жалобы
                reports = reports.map { r ->
                    if (r.videoId == v.id) r.copy(
                        status = "reviewed",
                        video = deleted
                    ) else r
                }
                toast("Видео удалено")
                closeDeletePanel()
            } catch (e: CancellationException) { throw e
            } catch (e: Exception) { toast("Ошибка: ${e.message}") }
            deleteBusy = false
        }
    }

    // ═══════════════════════════════ ПРОСМОТР ВИДЕО

    var viewerVideoId by mutableStateOf<String?>(null);    private set
    var viewerInitialIndex by mutableStateOf(0);           private set

    fun openViewer(video: Video) {
        val idx = feed.indexOfFirst { it.id == video.id }
        viewerVideoId = video.id
        viewerInitialIndex = if (idx >= 0) idx else 0
    }

    fun closeViewer() { viewerVideoId = null }

    // ═══════════════════════════════ ЖАЛОБЫ

    var reports by mutableStateOf<List<Report>>(emptyList()); private set
    var reportsLoading by mutableStateOf(false);              private set
    var reportsError by mutableStateOf<String?>(null);        private set
    var selectedReport by mutableStateOf<Report?>(null);      private set

    fun loadReports() {
        if (reportsLoading) return
        viewModelScope.launch {
            reportsLoading = true
            reportsError = null
            try { reports = repo.pendingReports() }
            catch (e: CancellationException) { throw e }
            catch (e: Exception) { reportsError = e.message }
            reportsLoading = false
        }
    }

    fun openReport(report: Report) { selectedReport = report }
    fun closeReport() { selectedReport = null }

    /** Нажать на видео из жалобы → открыть в ленте или напрямую */
    fun goToReportVideo(report: Report) {
        val video = report.video ?: return
        val inFeed = feed.indexOfFirst { it.id == video.id }
        if (inFeed >= 0) {
            // Уже есть в ленте — открыть просмотрщик
            viewerInitialIndex = inFeed
            viewerVideoId = video.id
        } else {
            // Добавить в начало ленты и открыть
            feed = listOf(video) + feed
            viewerInitialIndex = 0
            viewerVideoId = video.id
        }
        selectedReport = null
        tab = AdminTab.FEED
    }

    /** Отклонить жалобу без удаления видео */
    fun dismissReport(report: Report) {
        viewModelScope.launch {
            try {
                repo.dismissReport(report.id)
                reports = reports.filter { it.id != report.id }
                if (selectedReport?.id == report.id) selectedReport = null
                toast("Жалоба отклонена")
            } catch (e: CancellationException) { throw e }
            catch (e: Exception) { toast("Ошибка: ${e.message}") }
        }
    }

    // ═══════════════════════════════ АВТОРИЗАЦИЯ

    fun init() {
        viewModelScope.launch {
            loading = true
            try {
                val uid = api.currentUserId()
                if (uid != null) {
                    val email = api.userEmail ?: ""
                    if (email in ADMIN_EMAILS) {
                        meId = uid; isAdmin = true; authed = true
                        loadFeed()
                    } else {
                        api.signOut()
                        authError = "Нет доступа. Этот аккаунт не является администратором."
                    }
                }
            } catch (_: Exception) {}
            loading = false
        }
    }

    fun signIn(email: String, password: String) {
        viewModelScope.launch {
            authBusy = true; authError = ""
            try {
                api.signIn(email.trim(), password)
                val uid = api.currentUserId()
                val savedEmail = api.userEmail ?: email.trim()
                if (uid != null && savedEmail in ADMIN_EMAILS) {
                    meId = uid; isAdmin = true; authed = true
                    loadFeed()
                } else {
                    api.signOut()
                    authError = "Нет доступа. Этот аккаунт не является администратором."
                }
            } catch (e: CancellationException) { throw e
            } catch (e: Exception) { authError = e.message ?: "Ошибка входа" }
            authBusy = false
        }
    }

    fun signOut() {
        viewModelScope.launch {
            api.signOut()
            authed = false; isAdmin = false; meId = null
            feed = emptyList(); reports = emptyList()
            tab = AdminTab.FEED
        }
    }

    fun clearAuthError() { authError = "" }

    // ═══════════════════════════════ HELPERS

    private fun toast(text: String) =
        Toast.makeText(getApplication(), text, Toast.LENGTH_SHORT).show()
}
